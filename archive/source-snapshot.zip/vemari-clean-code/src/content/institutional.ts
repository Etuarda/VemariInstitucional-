export const institutionalContent = {
  annualTheme: 'O futuro se constrói no dia a dia.',
  mission: 'Transformar realidades através da evolução pessoal dos talentos impactando clientes.',
  worldview: {
    headline: 'Pessoas alcançando seu máximo potencial.',
    pillars: [
      { label: 'Espírito', value: 'Maduro' },
      { label: 'Mente', value: 'Equilibrada' },
      { label: 'Corpo', value: 'Funcional' },
    ],
  },
  purpose: 'Criar um ambiente próspero, rompendo barreiras espirituais, mentais e físicas.',
  values: [
    'Valorizamos a inovação',
    'Jogamos abertamente',
    'Desafiamos nossos limites',
    'Cuidamos da organização',
    'Realizamos o impossível',
  ],
  cultureCode: [
    'O combinado não sai caro.',
    'É melhor o feito do que o perfeito, mas não de qualquer jeito.',
    'Esforço não é garantia de resultado.',
    'Quebre regras, mas nunca quebre princípios.',
    'Pense como dono.',
    'Liderança é ser exemplo.',
    'Ser melhor do que ontem.',
    'Se é pra sonhar, que sonhe grande.',
    'Ouça quem tem resultados, e não opiniões.',
  ],
} as const;

export const aboutStory = [
  {
    eyebrow: '2017 / VALENÇA DO PIAUÍ',
    title: 'Tudo começou com 157 lotes.',
    body: [
      'Em 2017, em Valença do Piauí, começava uma história ainda chamada Agiliza Loteamentos. O primeiro empreendimento reunia 157 lotes. Era um começo de escala pequena quando comparado ao que viria depois, mas carregava uma ambição maior: tornar mais possível o caminho entre o desejo de ter um terreno e a construção de um lugar próprio.',
      'Antes dos números, vieram as primeiras escolhas. Antes da expansão, vieram os primeiros clientes. E antes de existir uma nova marca, era preciso construir algo mais importante: confiança.',
    ],
    requiresInternalApproval: true,
  },
  {
    eyebrow: 'PRIMEIRAS ENTREGAS',
    title: 'Um loteamento pode começar no papel. A confiança, não.',
    body: [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.',
    ],
    requiresInternalApproval: true,
  },
  {
    eyebrow: '2025 / UMA NOVA FASE',
    title: 'A empresa tinha crescido. O nome precisava crescer com ela.',
    body: [
      'Depois de anos de trajetória, Agiliza já não traduzia sozinha tudo o que a empresa pretendia construir. Em 2025, um processo de amadurecimento da marca levou a uma nova identidade: nascia Vemari.',
      'Não para apagar o que veio antes, mas para dar nome ao que a história havia se tornado e ao próximo capítulo que a empresa queria construir.',
    ],
    requiresInternalApproval: true,
  },
] as const;
