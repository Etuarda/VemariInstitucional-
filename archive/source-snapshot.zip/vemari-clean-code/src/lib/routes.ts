export const routes = {
  home: '/',
  about: '/sobre',
  developments: '/empreendimentos',
  brokers: '/corretores',
  locations: '/onde-estamos',
  contact: '/contato',
  privacy: '/politica-de-privacidade',
  terms: '/termos-de-uso',
  development: (slug: string) => `/empreendimentos/${slug}`,
  broker: (slug: string) => `/corretores/${slug}`,
} as const;
