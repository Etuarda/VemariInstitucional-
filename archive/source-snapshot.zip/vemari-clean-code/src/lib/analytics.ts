type AnalyticsValue = string | number | boolean | undefined;
type AnalyticsPayload = Record<string, AnalyticsValue>;

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
    fbq?: (...args: unknown[]) => void;
  }
}

export function trackEvent(name: string, payload: AnalyticsPayload = {}): void {
  if (typeof window === 'undefined') return;

  // Analytics nunca deve bloquear o fluxo comercial caso um provedor falhe ou seja bloqueado.
  try {
    window.gtag?.('event', name, payload);
  } catch {
    // Falha intencionalmente silenciosa: a conversão tem prioridade sobre telemetria.
  }
}

export function trackWhatsAppLead(contentName: string): void {
  if (typeof window === 'undefined') return;

  trackEvent('generate_lead', {
    currency: 'BRL',
    content_name: contentName,
  });

  try {
    window.fbq?.('track', 'Lead', { content_name: contentName });
  } catch {
    // A navegação para o WhatsApp deve continuar mesmo sem Meta Pixel disponível.
  }
}
