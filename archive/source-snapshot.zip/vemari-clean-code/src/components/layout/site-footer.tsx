import Link from 'next/link';
import { routes } from '@/lib/routes';

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-stone-800 bg-stone-950 text-white">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-20 md:grid-cols-4">
        <div>
          <p className="font-serif text-2xl">VEMARI</p>
          <p className="mt-2 font-mono text-xs uppercase tracking-widest text-stone-400">Vem. Acredita. Realiza.</p>
          <p className="mt-6 max-w-xs text-sm leading-6 text-stone-400">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>

        <FooterGroup title="Quero comprar" links={[
          [routes.developments, 'Empreendimentos'],
          [routes.locations, 'Onde estamos'],
          [routes.brokers, 'Encontre um corretor'],
        ]} />

        <FooterGroup title="A Vemari" links={[
          [routes.about, 'Sobre a Vemari'],
          [routes.about, 'Nossa história'],
          [routes.contact, 'Contato'],
        ]} />

        <FooterGroup title="Legal" links={[
          [routes.privacy, 'Política de Privacidade'],
          [routes.terms, 'Termos de Uso'],
        ]} />
      </div>

      <div className="mx-auto flex max-w-7xl flex-col gap-3 border-t border-stone-800 px-6 py-8 font-mono text-xs text-stone-500 md:flex-row md:justify-between">
        <p>VEMARI EMPREENDIMENTOS — Valença do Piauí — PI</p>
        <p>© 2026 Vemari Empreendimentos.</p>
      </div>
    </footer>
  );
}

interface FooterGroupProps {
  title: string;
  links: Array<readonly [string, string]>;
}

function FooterGroup({ title, links }: FooterGroupProps) {
  return (
    <div>
      <h2 className="font-mono text-xs uppercase tracking-widest text-stone-400">{title}</h2>
      <ul className="mt-5 space-y-3 text-sm text-stone-300">
        {links.map(([href, label]) => (
          <li key={`${href}-${label}`}><Link href={href}>{label}</Link></li>
        ))}
      </ul>
    </div>
  );
}
