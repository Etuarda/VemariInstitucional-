'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { routes } from '@/lib/routes';

const navigation = [
  { href: routes.developments, label: 'Empreendimentos' },
  { href: routes.locations, label: 'Onde estamos' },
  { href: routes.about, label: 'Sobre' },
  { href: routes.brokers, label: 'Corretores' },
  { href: routes.contact, label: 'Contato' },
];

export function SiteHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    if (!isMenuOpen) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isMenuOpen]);

  return (
    <header className="sticky top-0 z-50 border-b border-stone-200 bg-[#fbfbfa]">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <Link href={routes.home} aria-label="Vemari — página inicial">
          <span className="block font-serif text-2xl font-semibold tracking-wide">VEMARI</span>
          <span className="block font-mono text-[10px] uppercase tracking-[0.25em] text-stone-500">Empreendimentos</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Navegação principal">
          {navigation.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm text-stone-800 transition-colors hover:text-stone-500">
              {item.label}
            </Link>
          ))}
        </nav>

        <Link href={routes.contact} className="hidden border border-stone-950 bg-stone-950 px-5 py-3 font-mono text-xs uppercase tracking-widest text-white md:inline-flex">
          Fale com a Vemari →
        </Link>

        <button
          type="button"
          className="min-h-11 min-w-11 font-mono text-xs uppercase md:hidden"
          aria-expanded={isMenuOpen}
          aria-controls="mobile-navigation"
          onClick={() => setIsMenuOpen((current) => !current)}
        >
          {isMenuOpen ? 'Fechar' : 'Menu'}
        </button>
      </div>

      {isMenuOpen ? (
        <div id="mobile-navigation" className="fixed inset-x-0 bottom-0 top-20 z-50 bg-[#fbfbfa] px-6 py-10 md:hidden">
          <nav className="flex flex-col" aria-label="Navegação mobile">
            {navigation.map((item, index) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setIsMenuOpen(false)}
                className="border-b border-stone-200 py-5 font-serif text-2xl"
              >
                <span className="mr-4 font-mono text-xs text-stone-400">{String(index + 1).padStart(2, '0')}</span>
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      ) : null}
    </header>
  );
}
