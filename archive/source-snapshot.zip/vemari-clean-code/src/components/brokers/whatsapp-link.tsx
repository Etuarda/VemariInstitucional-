'use client';

import { useMemo } from 'react';
import { getActiveBrokerBySlug, vemariCentral } from '@/data/brokers';
import { readBrokerReference } from '@/lib/attribution';
import { trackWhatsAppLead } from '@/lib/analytics';
import { buildWhatsAppUrl } from '@/lib/whatsapp';

interface WhatsAppLinkProps {
  brokerSlug?: string;
  developmentName?: string;
  label: string;
  className?: string;
}

export function WhatsAppLink({ brokerSlug, developmentName, label, className = '' }: WhatsAppLinkProps) {
  const broker = useMemo(() => {
    if (brokerSlug) return getActiveBrokerBySlug(brokerSlug) ?? vemariCentral;

    // Em páginas de produto, a referência comercial persistida precede o atendimento central.
    const persisted = readBrokerReference();
    return (persisted && getActiveBrokerBySlug(persisted.brokerSlug)) || vemariCentral;
  }, [brokerSlug]);

  const href = buildWhatsAppUrl({
    phone: broker.whatsapp,
    brokerName: broker.slug === vemariCentral.slug ? undefined : broker.firstName,
    developmentName,
  });

  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className={className}
      onClick={() => trackWhatsAppLead(`whatsapp:${broker.slug}:${developmentName ?? 'general'}`)}
    >
      {label}
    </a>
  );
}
