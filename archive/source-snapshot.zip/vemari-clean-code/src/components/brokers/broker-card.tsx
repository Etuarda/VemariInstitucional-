import Link from 'next/link';
import type { Broker } from '@/domain/models';
import { routes } from '@/lib/routes';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';

interface BrokerCardProps {
  broker: Broker;
}

export function BrokerCard({ broker }: BrokerCardProps) {
  return (
    <article className="border-t border-stone-300 pt-6">
      {broker.photo ? (
        // eslint-disable-next-line @next/next/no-img-element -- substituir por next/image após padronização dos retratos no CMS.
        <img src={broker.photo} alt={`Retrato de ${broker.name}`} className="aspect-[3/4] w-full object-cover" />
      ) : (
        <MediaPlaceholder label="Retrato profissional — lorem ipsum" className="aspect-[3/4]" />
      )}

      <p className="mt-5 font-mono text-[11px] uppercase tracking-widest text-stone-500">Corretor Vemari</p>
      <h3 className="mt-2 font-serif text-2xl">{broker.name}</h3>
      <p className="mt-2 font-mono text-xs text-stone-500">CRECI {broker.creci} · {broker.city} — {broker.state}</p>
      <p className="mt-4 text-sm leading-6 text-stone-600">{broker.shortBio}</p>
      <Link href={routes.broker(broker.slug)} className="mt-6 inline-block font-mono text-xs uppercase underline underline-offset-8">
        Ver perfil →
      </Link>
    </article>
  );
}
