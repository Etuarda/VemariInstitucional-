'use client';

import { useMemo, useState } from 'react';
import type { Broker } from '@/domain/models';
import { BrokerCard } from './broker-card';

interface BrokerDirectoryProps {
  items: Broker[];
}

export function BrokerDirectory({ items }: BrokerDirectoryProps) {
  const [query, setQuery] = useState('');
  const [city, setCity] = useState('all');
  const cities = useMemo(() => [...new Set(items.map((item) => item.city))].sort(), [items]);

  const filtered = items.filter((broker) => {
    const matchesQuery = broker.name.toLocaleLowerCase('pt-BR').includes(query.trim().toLocaleLowerCase('pt-BR'));
    const matchesCity = city === 'all' || broker.city === city;
    return broker.active && matchesQuery && matchesCity;
  });

  return (
    <div>
      <div className="grid gap-5 border-y border-stone-300 py-6 md:grid-cols-[1fr_1fr_auto] md:items-end">
        <label className="grid gap-2 font-mono text-[11px] uppercase tracking-widest text-stone-500">
          Nome
          <input value={query} onChange={(event) => setQuery(event.target.value)} className="min-h-11 border border-stone-300 bg-white px-3 font-sans text-sm normal-case tracking-normal text-stone-900" placeholder="Digite um nome" />
        </label>
        <label className="grid gap-2 font-mono text-[11px] uppercase tracking-widest text-stone-500">
          Cidade
          <select value={city} onChange={(event) => setCity(event.target.value)} className="min-h-11 border border-stone-300 bg-white px-3 font-sans text-sm normal-case tracking-normal text-stone-900">
            <option value="all">Todas</option>
            {cities.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </label>
        <p className="font-mono text-xs text-stone-500">{filtered.length} especialista(s)</p>
      </div>

      {filtered.length ? (
        <div className="mt-12 grid gap-12 md:grid-cols-3">{filtered.map((broker) => <BrokerCard key={broker.id} broker={broker} />)}</div>
      ) : (
        <div className="border-b border-stone-300 py-20 text-center">
          <h2 className="font-serif text-2xl">Nenhum corretor encontrado.</h2>
          <p className="mt-3 text-sm text-stone-600">Ajuste os filtros ou fale com a Vemari.</p>
        </div>
      )}
    </div>
  );
}
