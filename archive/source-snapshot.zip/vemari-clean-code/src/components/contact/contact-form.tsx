'use client';

import { FormEvent, useState } from 'react';
import { formatBrazilianPhone, isValidBrazilianMobile } from '@/lib/formatters';
import { trackEvent } from '@/lib/analytics';

interface ContactFormState {
  name: string;
  phone: string;
  city: string;
  interest: string;
}

const initialState: ContactFormState = {
  name: '',
  phone: '',
  city: '',
  interest: '',
};

export function ContactForm() {
  const [form, setForm] = useState(initialState);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  function updateField<K extends keyof ContactFormState>(field: K, value: ContactFormState[K]) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitted(false);

    if (!form.name.trim()) {
      setError('Informe seu nome para continuar.');
      return;
    }

    if (!isValidBrazilianMobile(form.phone)) {
      setError('Informe um WhatsApp com 11 dígitos.');
      return;
    }

    setError(null);

    // TODO(integration): substituir pelo endpoint/CRM definido no roadmap antes do go-live.
    trackEvent('submit_lead', {
      city: form.city || undefined,
      interest: form.interest || undefined,
    });

    setSubmitted(true);
    setForm(initialState);
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="border-t border-stone-300 pt-8">
      <div className="grid gap-6 md:grid-cols-2">
        <Field label="Nome *">
          <input
            name="name"
            autoComplete="name"
            value={form.name}
            onChange={(event) => updateField('name', event.target.value)}
            className="min-h-12 w-full border border-stone-300 bg-white px-4"
          />
        </Field>

        <Field label="WhatsApp *">
          <input
            name="phone"
            inputMode="tel"
            autoComplete="tel"
            value={form.phone}
            onChange={(event) => updateField('phone', formatBrazilianPhone(event.target.value))}
            placeholder="(00) 90000-0000"
            className="min-h-12 w-full border border-stone-300 bg-white px-4"
            aria-describedby={error ? 'contact-error' : undefined}
          />
        </Field>

        <Field label="Cidade de interesse">
          <input
            name="city"
            value={form.city}
            onChange={(event) => updateField('city', event.target.value)}
            placeholder="Lorem Ipsum"
            className="min-h-12 w-full border border-stone-300 bg-white px-4"
          />
        </Field>

        <Field label="Interesse">
          <select
            name="interest"
            value={form.interest}
            onChange={(event) => updateField('interest', event.target.value)}
            className="min-h-12 w-full border border-stone-300 bg-white px-4"
          >
            <option value="">Selecione</option>
            <option value="buy-lot">Comprar um lote</option>
            <option value="broker">Falar com um corretor</option>
            <option value="customer">Já sou cliente</option>
            <option value="partnership">Parcerias</option>
            <option value="other">Outro</option>
          </select>
        </Field>
      </div>

      {error ? <p id="contact-error" role="alert" className="mt-5 text-sm text-red-700">{error}</p> : null}
      {submitted ? <p role="status" className="mt-5 text-sm text-emerald-800">Solicitação registrada para integração. Lorem ipsum.</p> : null}

      <button type="submit" className="mt-8 min-h-12 bg-stone-950 px-7 font-mono text-xs uppercase tracking-widest text-white">
        Continuar →
      </button>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-2 text-sm text-stone-700">
      <span className="font-mono text-[11px] uppercase tracking-widest text-stone-500">{label}</span>
      {children}
    </label>
  );
}
