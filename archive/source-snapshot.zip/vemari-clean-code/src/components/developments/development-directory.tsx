'use client';

import { useMemo, useState } from 'react';
import type { Development } from '@/domain/models';
import { DevelopmentCard } from './development-card';

interface DevelopmentDirectoryProps {
  items: Development[];
}

export function DevelopmentDirectory({ items }: DevelopmentDirectoryProps) {
  const [city, setCity] = useState('all');
  const [status, setStatus] = useState('all');

  const cities = useMemo(() => [...new Set(items.map((item) => item.city))].sort(), [items]);
  const filtered = items.filter((item) => {
    const matchesCity = city === 'all' || item.city === city;
    const matchesStatus = status === 'all' || item.status === status;
    return matchesCity && matchesStatus;
  });

  return (
    <div>
      <div className="grid gap-5 border-y border-stone-300 py-6 md:grid-cols-[1fr_1fr_auto] md:items-end">
        <FilterSelect label="Cidade" value={city} onChange={setCity} options={cities.map((value) => [value, value])} />
        <FilterSelect
          label="Status"
          value={status}
          onChange={setStatus}
          options={[
            ['launch', 'Lançamento'],
            ['in-development', 'Em desenvolvimento'],
            ['available', 'Disponível'],
            ['delivered', 'Entregue'],
            ['sold-out', '100% vendido'],
          ]}
        />
        <p className="font-mono text-xs text-stone-500">{filtered.length} resultado(s)</p>
      </div>

      {filtered.length ? (
        <div className="mt-12 grid gap-12 md:grid-cols-2">{filtered.map((item) => <DevelopmentCard key={item.id} development={item} />)}</div>
      ) : (
        <div className="border-b border-stone-300 py-20 text-center">
          <h2 className="font-serif text-2xl">Nenhum empreendimento encontrado.</h2>
          <p className="mt-3 text-sm text-stone-600">Ajuste os filtros para visualizar outras opções.</p>
        </div>
      )}
    </div>
  );
}

interface FilterSelectProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<[string, string]>;
}

function FilterSelect({ label, value, onChange, options }: FilterSelectProps) {
  return (
    <label className="grid gap-2 font-mono text-[11px] uppercase tracking-widest text-stone-500">
      {label}
      <select value={value} onChange={(event) => onChange(event.target.value)} className="min-h-11 border border-stone-300 bg-white px-3 font-sans text-sm normal-case tracking-normal text-stone-900">
        <option value="all">Todos</option>
        {options.map(([optionValue, optionLabel]) => <option key={optionValue} value={optionValue}>{optionLabel}</option>)}
      </select>
    </label>
  );
}
