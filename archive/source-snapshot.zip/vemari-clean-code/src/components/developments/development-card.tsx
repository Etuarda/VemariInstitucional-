import Link from 'next/link';
import type { Development } from '@/domain/models';
import { formatAreaRange } from '@/lib/formatters';
import { routes } from '@/lib/routes';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';

interface DevelopmentCardProps {
  development: Development;
}

export function DevelopmentCard({ development }: DevelopmentCardProps) {
  const area = formatAreaRange(development.areaMin, development.areaMax);

  return (
    <article className="border-t border-stone-300 pt-6">
      {development.image ? (
        // eslint-disable-next-line @next/next/no-img-element -- migrar para next/image quando o CMS fornecer dimensões confiáveis.
        <img src={development.image} alt="" className="aspect-[16/10] w-full object-cover" />
      ) : (
        <MediaPlaceholder label="Imagem do empreendimento — lorem ipsum" className="aspect-[16/10]" />
      )}

      <div className="mt-6 flex items-start justify-between gap-5">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-widest text-stone-500">{development.city} — {development.state}</p>
          <h3 className="mt-2 font-serif text-2xl text-stone-950">{development.name}</h3>
          <p className="mt-3 max-w-md text-sm leading-6 text-stone-600">{development.tagline}</p>
          {area ? <p className="mt-4 font-mono text-xs text-stone-500">LOTES {area}</p> : null}
        </div>
        <Link href={routes.development(development.slug)} className="shrink-0 font-mono text-xs uppercase underline underline-offset-8">
          Conhecer →
        </Link>
      </div>
    </article>
  );
}
