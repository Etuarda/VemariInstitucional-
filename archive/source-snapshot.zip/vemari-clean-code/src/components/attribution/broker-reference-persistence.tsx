'use client';

import { useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { getActiveBrokerBySlug } from '@/data/brokers';
import { persistBrokerReference } from '@/lib/attribution';

export function BrokerReferencePersistence() {
  const searchParams = useSearchParams();

  useEffect(() => {
    const brokerSlug = searchParams.get('ref');
    if (!brokerSlug) return;

    // Apenas referências conhecidas são persistidas para impedir atribuição a slugs inválidos ou manipulados.
    if (getActiveBrokerBySlug(brokerSlug)) {
      persistBrokerReference(brokerSlug);
    }
  }, [searchParams]);

  return null;
}
