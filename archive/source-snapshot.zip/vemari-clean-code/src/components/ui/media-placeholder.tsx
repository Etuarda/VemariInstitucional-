interface MediaPlaceholderProps {
  label: string;
  className?: string;
}

export function MediaPlaceholder({ label, className = '' }: MediaPlaceholderProps) {
  return (
    <div className={`flex min-h-64 items-end border border-stone-300 bg-stone-100 p-5 ${className}`}>
      <span className="font-mono text-[11px] uppercase tracking-widest text-stone-500">{label}</span>
    </div>
  );
}
