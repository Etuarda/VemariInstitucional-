interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
}

export function SectionHeading({ eyebrow, title, description }: SectionHeadingProps) {
  return (
    <div className="max-w-3xl">
      <span className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">{eyebrow}</span>
      <h2 className="mt-3 font-serif text-3xl leading-tight text-stone-950 md:text-5xl">{title}</h2>
      {description ? <p className="mt-5 max-w-2xl text-base leading-7 text-stone-600">{description}</p> : null}
    </div>
  );
}
