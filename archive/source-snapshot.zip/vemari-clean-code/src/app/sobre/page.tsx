import Link from 'next/link';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';
import { aboutStory, institutionalContent } from '@/content/institutional';
import { routes } from '@/lib/routes';

export const metadata = { title: 'Sobre a Vemari' };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Nossa história</p>
      <h1 className="mt-5 max-w-4xl font-serif text-5xl leading-[1.05] md:text-7xl">Antes de existir Vemari, existia uma ideia.</h1>
      <p className="mt-7 max-w-3xl text-xl leading-9 text-stone-600">Fazer com que mais pessoas pudessem olhar para um lugar e enxergar ali o começo de uma história própria.</p>
      <MediaPlaceholder label="Acervo histórico Vemari — validar mídia" className="mt-14 aspect-[16/7]" />

      <div className="mt-24 space-y-20">
        {aboutStory.map((chapter) => (
          <article key={chapter.title} className="grid gap-8 border-t border-stone-300 pt-10 md:grid-cols-[220px_1fr]">
            <p className="font-mono text-xs uppercase tracking-widest text-stone-500">{chapter.eyebrow}</p>
            <div>
              <h2 className="font-serif text-3xl md:text-5xl">{chapter.title}</h2>
              <div className="mt-6 max-w-3xl space-y-4 text-base leading-8 text-stone-650">{chapter.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div>
            </div>
          </article>
        ))}
      </div>

      <section className="mt-24 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Missão</p>
        <h2 className="mt-3 font-serif text-4xl">Transformar realidades através da evolução.</h2>
        <p className="mt-5 max-w-3xl text-lg leading-8 text-stone-600">{institutionalContent.mission}</p>
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Visão de mundo</p>
        <h2 className="mt-3 font-serif text-4xl">{institutionalContent.worldview.headline}</h2>
        <div className="mt-10 grid gap-0 border-y border-stone-300 md:grid-cols-3">
          {institutionalContent.worldview.pillars.map((pillar, index) => (
            <div key={pillar.label} className="border-b border-stone-300 py-8 md:border-b-0 md:border-r md:px-8 first:md:pl-0 last:md:border-r-0">
              <p className="font-mono text-xs text-stone-400">0{index + 1}</p>
              <p className="mt-4 font-mono text-xs uppercase tracking-widest text-stone-500">{pillar.label}</p>
              <p className="mt-2 font-serif text-3xl">{pillar.value}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Propósito</p>
        <h2 className="mt-3 font-serif text-4xl">Criar um ambiente próspero.</h2>
        <p className="mt-5 max-w-3xl text-lg leading-8 text-stone-600">{institutionalContent.purpose}</p>
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Nossos valores</p>
        <h2 className="mt-3 font-serif text-4xl">A forma como fazemos importa.</h2>
        <ol className="mt-10">{institutionalContent.values.map((value, index) => <li key={value} className="grid grid-cols-[48px_1fr] border-t border-stone-300 py-7"><span className="font-mono text-xs text-stone-400">0{index + 1}</span><span className="font-serif text-2xl">{value}</span></li>)}</ol>
      </section>

      <section className="mt-24 border-t border-stone-300 pt-14">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">O próximo capítulo</p>
        <h2 className="mt-4 max-w-3xl font-serif text-4xl md:text-5xl">Toda grande história de território termina começando outra.</h2>
        <p className="mt-5 max-w-2xl text-lg text-stone-600">A nossa continua. A próxima pode começar com a escolha do lugar onde você vai construir, investir ou viver.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href={routes.developments} className="bg-stone-950 px-6 py-4 font-mono text-xs uppercase tracking-widest text-white">Conheça os empreendimentos →</Link><Link href={routes.brokers} className="border border-stone-400 px-6 py-4 font-mono text-xs uppercase tracking-widest">Encontre um corretor →</Link></div>
      </section>
    </div>
  );
}
