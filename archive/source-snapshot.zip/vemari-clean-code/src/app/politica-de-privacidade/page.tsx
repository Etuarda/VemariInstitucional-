export const metadata = { title: 'Política de Privacidade' };

export default function PrivacyPage() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Legal</p>
      <h1 className="mt-4 font-serif text-5xl">Política de Privacidade</h1>
      <div className="mt-10 space-y-6 text-base leading-8 text-stone-600">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
        <h2 className="font-serif text-2xl text-stone-950">Coleta e tratamento de dados</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </article>
  );
}
