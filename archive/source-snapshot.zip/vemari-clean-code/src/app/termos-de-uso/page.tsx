export const metadata = { title: 'Termos de Uso' };

export default function TermsPage() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Legal</p>
      <h1 className="mt-4 font-serif text-5xl">Termos de Uso</h1>
      <div className="mt-10 space-y-6 text-base leading-8 text-stone-600">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
        <h2 className="font-serif text-2xl text-stone-950">Uso da plataforma</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </article>
  );
}
