import { notFound } from 'next/navigation';
import { WhatsAppLink } from '@/components/brokers/whatsapp-link';
import { DevelopmentCard } from '@/components/developments/development-card';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';
import { brokers, getBrokerBySlug } from '@/data/brokers';
import { developments } from '@/data/developments';

interface BrokerPageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return brokers.map(({ slug }) => ({ slug }));
}

export default async function BrokerPage({ params }: BrokerPageProps) {
  const { slug } = await params;
  const broker = getBrokerBySlug(slug);
  if (!broker || !broker.active) notFound();

  const related = developments.filter((development) => broker.developmentSlugs.includes(development.slug));

  return (
    <div className="mx-auto max-w-7xl px-6 py-20">
      <section className="grid gap-12 lg:grid-cols-12 lg:items-end">
        <MediaPlaceholder label="Retrato profissional do corretor" className="aspect-[3/4] lg:col-span-5" />
        <div className="lg:col-span-7">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Corretor Vemari</p>
          <h1 className="mt-4 font-serif text-5xl md:text-7xl">{broker.name}</h1>
          <p className="mt-4 font-mono text-xs uppercase tracking-widest text-stone-500">CRECI {broker.creci} · {broker.city} — {broker.state}</p>
          <p className="mt-7 max-w-2xl text-lg leading-8 text-stone-600">Uma boa escolha começa com informação clara sobre o lugar onde você pretende investir.</p>
          <WhatsAppLink brokerSlug={broker.slug} label={`Falar com ${broker.firstName} →`} className="mt-8 inline-block bg-stone-950 px-6 py-4 font-mono text-xs uppercase tracking-widest text-white" />
        </div>
      </section>

      <section className="mt-24 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Como posso ajudar</p>
        <h2 className="mt-3 font-serif text-4xl">Escolher um terreno é uma decisão importante. Você não precisa fazer isso sozinho.</h2>
        <div className="mt-10 grid border-y border-stone-300 md:grid-cols-4">{['Conhecer os empreendimentos', 'Encontrar terrenos', 'Entender condições', 'Agendar uma visita'].map((item, index) => <div key={item} className="border-b border-stone-300 py-7 md:border-b-0 md:border-r md:px-5 last:md:border-r-0"><span className="font-mono text-xs text-stone-400">0{index + 1}</span><p className="mt-4 font-serif text-xl">{item}</p></div>)}</div>
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Atendimento</p>
        <h2 className="mt-3 font-serif text-4xl">Empreendimentos que posso apresentar a você.</h2>
        <div className="mt-10 grid gap-12 md:grid-cols-2">{related.map((development) => <DevelopmentCard key={development.id} development={development} />)}</div>
      </section>

      <section className="mt-20 grid gap-10 border-t border-stone-300 pt-12 md:grid-cols-2">
        <div><p className="font-mono text-xs uppercase tracking-widest text-stone-500">Conhecimento local</p><h2 className="mt-3 font-serif text-4xl">Conhecer o território faz diferença.</h2><p className="mt-5 text-stone-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p></div>
        <div><p className="font-mono text-xs uppercase tracking-widest text-stone-500">Quem vai acompanhar você</p><h2 className="mt-3 font-serif text-4xl">{broker.name}</h2><p className="mt-5 text-stone-600">{broker.shortBio}</p></div>
      </section>

      <section className="mt-24 bg-stone-950 px-6 py-16 text-white md:px-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-400">Próximo passo</p>
        <h2 className="mt-4 max-w-3xl font-serif text-4xl md:text-5xl">Vamos encontrar seu próximo terreno?</h2>
        <p className="mt-5 text-stone-300">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <WhatsAppLink brokerSlug={broker.slug} label={`Falar com ${broker.firstName} pelo WhatsApp →`} className="mt-8 inline-block border border-white px-6 py-4 font-mono text-xs uppercase tracking-widest" />
      </section>
    </div>
  );
}
