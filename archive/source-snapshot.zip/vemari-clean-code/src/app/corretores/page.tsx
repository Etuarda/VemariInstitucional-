import { BrokerDirectory } from '@/components/brokers/broker-directory';
import { brokers } from '@/data/brokers';

export const metadata = { title: 'Corretores' };

export default function BrokersPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Especialistas Vemari</p>
      <h1 className="mt-5 max-w-5xl font-serif text-5xl leading-[1.05] md:text-7xl">Encontre quem conhece o empreendimento e pode acompanhar sua escolha.</h1>
      <p className="mt-7 max-w-3xl text-lg leading-8 text-stone-600">Escolha um especialista Vemari para conhecer empreendimentos, tirar dúvidas, entender condições e receber um atendimento mais próximo em cada etapa.</p>
      <div className="mt-12"><BrokerDirectory items={brokers} /></div>
    </div>
  );
}
