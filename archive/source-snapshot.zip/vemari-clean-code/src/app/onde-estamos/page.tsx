import Link from 'next/link';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';
import { routes } from '@/lib/routes';

export const metadata = { title: 'Onde estamos' };

export default function LocationsPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Território Vemari</p>
      <h1 className="mt-5 max-w-5xl font-serif text-5xl leading-[1.05] md:text-7xl">Crescemos junto com os territórios onde estamos.</h1>
      <p className="mt-7 max-w-3xl text-lg leading-8 text-stone-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
      <MediaPlaceholder label="Mapa territorial SVG — localidades a validar" className="mt-14 aspect-[16/8]" />
      <section className="mt-20 border-t border-stone-300 pt-12">
        <h2 className="font-serif text-4xl">Onde a Vemari está presente.</h2>
        <div className="mt-10 grid gap-10 md:grid-cols-2">
          {['Lorem Ipsum — PI', 'Lorem Ipsum — MA'].map((location) => (
            <article key={location} className="border-t border-stone-300 pt-6">
              <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Território</p>
              <h3 className="mt-3 font-serif text-3xl">{location}</h3>
              <p className="mt-4 text-sm leading-6 text-stone-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </article>
          ))}
        </div>
        <Link href={routes.developments} className="mt-10 inline-block font-mono text-xs uppercase underline underline-offset-8">Ver empreendimentos →</Link>
      </section>
    </div>
  );
}
