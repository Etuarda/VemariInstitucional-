import { DevelopmentDirectory } from '@/components/developments/development-directory';
import { developments } from '@/data/developments';

export const metadata = { title: 'Empreendimentos' };

export default function DevelopmentsPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Empreendimentos Vemari</p>
      <h1 className="mt-5 max-w-5xl font-serif text-5xl leading-[1.05] md:text-7xl">Encontre o terreno que faz sentido para o seu próximo passo.</h1>
      <p className="mt-7 max-w-2xl text-lg leading-8 text-stone-600">Explore os empreendimentos Vemari, conheça diferentes localizações e encontre informações para comparar suas opções com mais clareza.</p>
      <div className="mt-12"><DevelopmentDirectory items={developments} /></div>
    </div>
  );
}
