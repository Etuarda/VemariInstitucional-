import { notFound } from 'next/navigation';
import { WhatsAppLink } from '@/components/brokers/whatsapp-link';
import { BrokerCard } from '@/components/brokers/broker-card';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';
import { brokers } from '@/data/brokers';
import { developments, getDevelopmentBySlug } from '@/data/developments';
import { formatAreaRange } from '@/lib/formatters';

interface DevelopmentPageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return developments.map(({ slug }) => ({ slug }));
}

export default async function DevelopmentPage({ params }: DevelopmentPageProps) {
  const { slug } = await params;
  const development = getDevelopmentBySlug(slug);
  if (!development) notFound();

  const area = formatAreaRange(development.areaMin, development.areaMax);
  const relatedBrokers = brokers.filter((broker) => development.brokerSlugs.includes(broker.slug) && broker.active);

  return (
    <div className="mx-auto max-w-7xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">{development.city} — {development.state}</p>
      <h1 className="mt-4 font-serif text-5xl md:text-7xl">{development.name}</h1>
      <p className="mt-6 max-w-3xl text-lg leading-8 text-stone-600">{development.tagline}</p>
      <div className="mt-8 flex flex-wrap gap-3">
        <WhatsAppLink developmentName={development.name} label="Falar sobre este empreendimento →" className="bg-stone-950 px-6 py-4 font-mono text-xs uppercase tracking-widest text-white" />
      </div>

      <MediaPlaceholder label="Imagem principal do empreendimento — lorem ipsum" className="mt-14 aspect-[16/8]" />

      <dl className="mt-12 grid border-y border-stone-300 md:grid-cols-4">
        <Fact label="Status" value={development.status} />
        {area ? <Fact label="Área dos lotes" value={area} /> : null}
        {development.totalLots ? <Fact label="Total de lotes" value={String(development.totalLots)} /> : null}
        <Fact label="Localização" value={`${development.city} — ${development.state}`} />
      </dl>

      <section className="mt-20 max-w-3xl">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">O empreendimento</p>
        <h2 className="mt-3 font-serif text-4xl">Um novo endereço para viver ou investir.</h2>
        <p className="mt-5 text-base leading-8 text-stone-600">{development.description}</p>
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Infraestrutura urbana</p>
        <h2 className="mt-3 font-serif text-4xl">Planejado para sustentar o desenvolvimento do território.</h2>
        <ol className="mt-10 grid gap-0 md:grid-cols-2">{development.infrastructure.map((item, index) => <li key={item} className="grid grid-cols-[48px_1fr] border-t border-stone-300 py-6"><span className="font-mono text-xs text-stone-400">0{index + 1}</span><span>{item}</span></li>)}</ol>
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Implantação</p>
        <h2 className="mt-3 font-serif text-4xl">Escolha onde sua história começa.</h2>
        <p className="mt-5 max-w-2xl text-stone-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <MediaPlaceholder label="Mapa SVG interativo — implementar após base de lotes validada" className="mt-8 aspect-[16/9]" />
      </section>

      <section className="mt-20 border-t border-stone-300 pt-12">
        <p className="font-mono text-xs uppercase tracking-widest text-stone-500">Atendimento especializado</p>
        <h2 className="mt-3 font-serif text-4xl">Fale com quem conhece este empreendimento.</h2>
        <div className="mt-10 grid gap-12 md:grid-cols-3">{relatedBrokers.map((broker) => <BrokerCard key={broker.id} broker={broker} />)}</div>
      </section>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return <div className="border-b border-stone-300 py-6 md:border-b-0 md:border-r md:px-6 first:md:pl-0 last:md:border-r-0"><dt className="font-mono text-[10px] uppercase tracking-widest text-stone-500">{label}</dt><dd className="mt-2 text-sm">{value}</dd></div>;
}
