import { ContactForm } from '@/components/contact/contact-form';

export const metadata = { title: 'Contato' };

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-5xl px-6 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Fale com a Vemari</p>
      <h1 className="mt-5 max-w-4xl font-serif text-5xl leading-[1.05] md:text-7xl">Estamos prontos para conversar com você.</h1>
      <p className="mt-7 max-w-2xl text-lg leading-8 text-stone-600">Conte o que você procura para direcionarmos seu contato ao atendimento adequado.</p>
      <div className="mt-14"><ContactForm /></div>
    </div>
  );
}
