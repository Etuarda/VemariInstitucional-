import Link from 'next/link';
import { BrokerCard } from '@/components/brokers/broker-card';
import { DevelopmentCard } from '@/components/developments/development-card';
import { MediaPlaceholder } from '@/components/ui/media-placeholder';
import { SectionHeading } from '@/components/ui/section-heading';
import { brokers } from '@/data/brokers';
import { getFeaturedDevelopments } from '@/data/developments';
import { routes } from '@/lib/routes';

export default function HomePage() {
  const featured = getFeaturedDevelopments();

  return (
    <>
      <section className="border-b border-stone-300 py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-500">Vemari Empreendimentos</p>
            <h1 className="mt-5 max-w-4xl font-serif text-5xl leading-[1.03] md:text-7xl">Territórios para o que vem depois.</h1>
            <p className="mt-7 max-w-2xl text-lg leading-8 text-stone-600">Desenvolvemos espaços para novas histórias, novos endereços e novas possibilidades de crescimento.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href={routes.developments} className="border border-stone-950 bg-stone-950 px-6 py-4 text-center font-mono text-xs uppercase tracking-widest text-white">Conheça nossos empreendimentos →</Link>
              <Link href={routes.brokers} className="border border-stone-400 px-6 py-4 text-center font-mono text-xs uppercase tracking-widest">Fale com um corretor</Link>
            </div>
          </div>
          <MediaPlaceholder label="Hero institucional — fotografia ou vídeo real" className="aspect-[4/5] lg:col-span-5" />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-24">
        <SectionHeading eyebrow="Empreendimentos" title="Territórios em desenvolvimento." description="Lorem ipsum dolor sit amet, consectetur adipiscing elit." />
        <div className="mt-14 grid gap-12 md:grid-cols-2">{featured.map((item) => <DevelopmentCard key={item.id} development={item} />)}</div>
        <Link href={routes.developments} className="mt-10 inline-block font-mono text-xs uppercase underline underline-offset-8">Ver todos os empreendimentos →</Link>
      </section>

      <section className="bg-stone-950 py-28 text-white">
        <div className="mx-auto max-w-5xl px-6">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-stone-400">Vemari</p>
          <h2 className="mt-5 font-serif text-5xl leading-none md:text-7xl">Vem.<br />Acredita.<br />Realiza.</h2>
          <p className="mt-8 max-w-2xl text-lg leading-8 text-stone-300">Acreditamos que transformar um território também é abrir espaço para que pessoas, famílias e cidades continuem avançando.</p>
          <Link href={routes.about} className="mt-9 inline-block border border-stone-500 px-6 py-4 font-mono text-xs uppercase tracking-widest">Conheça nossa história →</Link>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-24">
        <SectionHeading eyebrow="Especialistas Vemari" title="Encontre quem pode acompanhar sua escolha." description="Escolha um especialista para conhecer empreendimentos, tirar dúvidas e avançar com mais clareza." />
        <div className="mt-14 grid gap-12 md:grid-cols-3">{brokers.slice(0, 3).map((broker) => <BrokerCard key={broker.id} broker={broker} />)}</div>
        <Link href={routes.brokers} className="mt-10 inline-block font-mono text-xs uppercase underline underline-offset-8">Encontrar um corretor →</Link>
      </section>
    </>
  );
}
