import type { Broker } from '@/domain/models';

const LOREM =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.';

export const brokers: Broker[] = [
  {
    id: 'nome-sobrenome',
    slug: 'nome-sobrenome',
    name: 'Nome Sobrenome',
    firstName: 'Nome',
    creci: 'XXXXX',
    city: 'Lorem Ipsum',
    state: 'PI',
    region: 'Lorem Ipsum',
    whatsapp: '5589999999999',
    shortBio: LOREM,
    developmentSlugs: ['lorem-empreendimento-01', 'lorem-empreendimento-02'],
    active: true,
  },
];

export const CENTRAL_BROKER_SLUG = 'vemari-central';

export const vemariCentral: Broker = {
  id: CENTRAL_BROKER_SLUG,
  slug: CENTRAL_BROKER_SLUG,
  name: 'Vemari Central',
  firstName: 'Vemari',
  creci: '',
  city: 'Valença do Piauí',
  state: 'PI',
  region: 'Atendimento Vemari',
  whatsapp: '5589999999999',
  shortBio: LOREM,
  developmentSlugs: [],
  active: true,
};

export function getBrokerBySlug(slug: string): Broker | undefined {
  return brokers.find((broker) => broker.slug === slug);
}

export function getActiveBrokerBySlug(slug: string): Broker | undefined {
  const broker = getBrokerBySlug(slug);
  return broker?.active ? broker : undefined;
}
