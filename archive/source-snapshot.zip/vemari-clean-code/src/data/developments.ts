import type { Development } from '@/domain/models';

const LOREM =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.';

export const developments: Development[] = [
  {
    id: 'lorem-empreendimento-01',
    slug: 'lorem-empreendimento-01',
    name: 'Lorem Ipsum Empreendimento',
    city: 'Lorem Ipsum',
    state: 'PI',
    status: 'available',
    tagline: LOREM,
    description: LOREM,
    infrastructure: [
      'Lorem ipsum infraestrutura 01',
      'Lorem ipsum infraestrutura 02',
      'Lorem ipsum infraestrutura 03',
    ],
    progress: [],
    faqs: [
      {
        question: 'Como funciona a compra de um lote?',
        answer: LOREM,
      },
      {
        question: 'Posso visitar o empreendimento?',
        answer: LOREM,
      },
    ],
    brokerSlugs: ['nome-sobrenome'],
    featured: true,
  },
  {
    id: 'lorem-empreendimento-02',
    slug: 'lorem-empreendimento-02',
    name: 'Lorem Ipsum Território',
    city: 'Lorem Ipsum',
    state: 'PI',
    status: 'in-development',
    tagline: LOREM,
    description: LOREM,
    infrastructure: [
      'Lorem ipsum infraestrutura 01',
      'Lorem ipsum infraestrutura 02',
    ],
    progress: [],
    faqs: [],
    brokerSlugs: ['nome-sobrenome'],
    featured: true,
  },
];

export function getDevelopmentBySlug(slug: string): Development | undefined {
  return developments.find((development) => development.slug === slug);
}

export function getFeaturedDevelopments(): Development[] {
  return developments.filter((development) => development.featured);
}
