export type DevelopmentStatus =
  | 'launch'
  | 'in-development'
  | 'available'
  | 'delivered'
  | 'sold-out';

export type LotStatus = 'available' | 'reserved' | 'sold';

export interface DevelopmentProgress {
  key: string;
  label: string;
  percentage: number;
  updatedAt?: string;
}

export interface DevelopmentFaq {
  question: string;
  answer: string;
}

export interface Development {
  id: string;
  slug: string;
  name: string;
  city: string;
  state: string;
  status: DevelopmentStatus;
  tagline: string;
  description: string;
  image?: string;
  areaMin?: number;
  areaMax?: number;
  totalLots?: number;
  infrastructure: string[];
  progress: DevelopmentProgress[];
  faqs: DevelopmentFaq[];
  brokerSlugs: string[];
  featured: boolean;
}

export interface BrokerStats {
  clients?: number;
  developments?: number;
  yearsExperience?: number;
}

export interface Broker {
  id: string;
  slug: string;
  name: string;
  firstName: string;
  creci: string;
  city: string;
  state: string;
  region: string;
  whatsapp: string;
  photo?: string;
  shortBio: string;
  developmentSlugs: string[];
  stats?: BrokerStats;
  active: boolean;
}

export interface BrokerReference {
  brokerSlug: string;
  firstTouchAt: string;
  lastTouchAt: string;
  expiresAt: string;
}
