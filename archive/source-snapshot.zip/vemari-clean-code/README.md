# Vemari — Refatoração Clean Code

Esta pasta contém a refatoração arquitetural do protótipo monolítico para uma base compatível com **Next.js App Router + React + TypeScript**.

## Decisões principais

- Rotas reais do App Router substituem `currentRoute` e `navigateTo`.
- Server Components são o padrão; `use client` só existe em filtros, menu, formulário, analytics e atribuição.
- Dados de negócio são tipados e separados da UI.
- Valores desconhecidos não são inventados: permanecem como Lorem Ipsum ou campos opcionais.
- Conteúdo institucional aprovado fica em `src/content/institutional.ts`.
- Empreendimentos e corretores ficam em repositórios próprios, preparados para migração a CMS/API.
- `?ref=` é persistido por 30 dias e validado contra corretores conhecidos.
- WhatsApp é gerado por função pura e recebe contexto do empreendimento/corretor.
- Analytics é best-effort: falhas de pixel nunca bloqueiam conversão.
- Geometria evita arredondamento excessivo, gradientes e estética de template SaaS.

## Política de comentários

Os comentários seguem o princípio de Clean Code: **explicam por que uma decisão existe**, não narram o que a linha seguinte já deixa claro.

Comentários aceitáveis no projeto:

```ts
// O primeiro toque é preservado para não perder a origem comercial inicial do lead.
```

Comentários evitados:

```ts
// Filtra os corretores
const filtered = brokers.filter(...)
```

## Estrutura

```text
src/
├── app/                   # rotas e composição de páginas
├── components/
│   ├── attribution/       # persistência de ?ref=
│   ├── brokers/           # componentes comerciais de corretores
│   ├── contact/           # formulário e validação
│   ├── developments/      # catálogo e cards
│   ├── layout/            # header/footer
│   └── ui/                # componentes visuais agnósticos
├── content/               # conteúdo institucional/editorial
├── data/                  # mocks tipados; futura camada CMS/API
├── domain/                # contratos de domínio
└── lib/                   # regras puras e infraestrutura leve
```

## Pendências antes de produção

1. Substituir telefones e corretores placeholder por dados autorizados.
2. Validar fatos históricos marcados no backlog como `[VALIDAR]`.
3. Substituir Lorem Ipsum de empreendimentos/cidades por conteúdo aprovado.
4. Conectar formulário ao CRM/API.
5. Definir CMS.
6. Implementar imagens reais com `next/image` após dimensões e política de mídia estarem consolidadas.
7. Implementar mapa SVG de lotes somente após fonte única de disponibilidade.
8. Validar brandbook e tokens de cor.
9. Criar política LGPD jurídica definitiva.
10. Configurar GA4/Meta/GTM conforme governança aprovada.

## Observação

O código original usava JSX em arquivo `.ts`. Componentes React com JSX devem usar extensão `.tsx`.
